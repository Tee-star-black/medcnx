'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock3,
  FileText,
  Loader2,
  Plus,
  RefreshCw,
  ShieldCheck,
  Trash2,
  WalletCards,
  XCircle,
} from 'lucide-react';
import { DashboardShell } from '@/components/dashboard/DashboardShell';
import { api } from '@/lib/api';

type PayrollRunStatus = 'DRAFT' | 'FINALISED' | 'CANCELLED';

type PayrollRun = {
  id: string;
  organisationId: string;
  title: string;
  periodMonth: number;
  periodYear: number;
  status: PayrollRunStatus;
  employeeCount: number;
  itemCount: number;
  totalGrossPay: number;
  totalPaye: number;
  totalUifEmployee: number;
  totalDeductions: number;
  totalNetPay: number;
  totalEmployerContributions: number;
  notes?: string | null;
  finalisedAt?: string | null;
  createdAt: string;
  updatedAt: string;
  createdBy?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
  } | null;
  finalisedBy?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
  } | null;
};

type CreatePayrollRunResponse = {
  message: string;
  payrollRun: PayrollRun;
};

const months = [
  { value: 1, label: 'January' },
  { value: 2, label: 'February' },
  { value: 3, label: 'March' },
  { value: 4, label: 'April' },
  { value: 5, label: 'May' },
  { value: 6, label: 'June' },
  { value: 7, label: 'July' },
  { value: 8, label: 'August' },
  { value: 9, label: 'September' },
  { value: 10, label: 'October' },
  { value: 11, label: 'November' },
  { value: 12, label: 'December' },
];

function currentMonth() {
  return new Date().getMonth() + 1;
}

function currentYear() {
  return new Date().getFullYear();
}

function monthLabel(month: number) {
  return months.find((item) => item.value === month)?.label ?? `Month ${month}`;
}

function formatCurrency(value?: number | null) {
  return new Intl.NumberFormat('en-ZA', {
    style: 'currency',
    currency: 'ZAR',
  }).format(value ?? 0);
}

function formatDate(value?: string | null) {
  if (!value) {
    return 'Not set';
  }

  return new Intl.DateTimeFormat('en-ZA', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  }).format(new Date(value));
}

function statusLabel(status: PayrollRunStatus) {
  if (status === 'FINALISED') return 'Finalised';
  if (status === 'CANCELLED') return 'Cancelled';
  return 'Draft';
}

function statusClass(status: PayrollRunStatus) {
  if (status === 'FINALISED') {
    return 'border-emerald-200 bg-emerald-50 text-emerald-700';
  }

  if (status === 'CANCELLED') {
    return 'border-red-200 bg-red-50 text-red-700';
  }

  return 'border-amber-200 bg-amber-50 text-amber-700';
}

function statusIcon(status: PayrollRunStatus) {
  if (status === 'FINALISED') return <CheckCircle2 size={14} />;
  if (status === 'CANCELLED') return <XCircle size={14} />;
  return <Clock3 size={14} />;
}

export default function PayrollRunsPage() {
  const [runs, setRuns] = useState<PayrollRun[]>([]);
  const [periodMonth, setPeriodMonth] = useState(currentMonth());
  const [periodYear, setPeriodYear] = useState(currentYear());
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');

  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [workingRunId, setWorkingRunId] = useState('');

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadPayrollRuns();
  }, []);

  const draftRuns = useMemo(() => {
    return runs.filter((run) => run.status === 'DRAFT');
  }, [runs]);

  const finalisedRuns = useMemo(() => {
    return runs.filter((run) => run.status === 'FINALISED');
  }, [runs]);

  const totalNetPay = useMemo(() => {
    return runs.reduce((sum, run) => sum + Number(run.totalNetPay ?? 0), 0);
  }, [runs]);

  const totalGrossPay = useMemo(() => {
    return runs.reduce((sum, run) => sum + Number(run.totalGrossPay ?? 0), 0);
  }, [runs]);

  async function loadPayrollRuns() {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await api.get<PayrollRun[]>('/payroll/runs');
      setRuns(response.data);
    } catch (requestError: any) {
      const message =
        requestError?.response?.data?.message ?? 'Could not load payroll runs.';

      setError(Array.isArray(message) ? message.join(' ') : message);
    } finally {
      setLoading(false);
    }
  }

  async function createPayrollRun(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setCreating(true);
    setError('');
    setSuccess('');

    try {
      const response = await api.post<CreatePayrollRunResponse>(
        '/payroll/runs',
        {
          title: title.trim() || undefined,
          periodMonth,
          periodYear,
          notes: notes.trim() || undefined,
        },
      );

      setRuns((current) => [response.data.payrollRun, ...current]);
      setTitle('');
      setNotes('');
      setSuccess(response.data.message);
    } catch (requestError: any) {
      const message =
        requestError?.response?.data?.message ?? 'Could not create payroll run.';

      setError(Array.isArray(message) ? message.join(' ') : message);
    } finally {
      setCreating(false);
    }
  }

  async function finaliseRun(runId: string) {
    const confirmed = window.confirm(
      'Finalise this payroll run? You will not be able to delete it after finalising.',
    );

    if (!confirmed) return;

    setWorkingRunId(runId);
    setError('');
    setSuccess('');

    try {
      const response = await api.patch<CreatePayrollRunResponse>(
        `/payroll/runs/${runId}/finalise`,
      );

      setRuns((current) =>
        current.map((run) =>
          run.id === runId ? response.data.payrollRun : run,
        ),
      );

      setSuccess(response.data.message);
    } catch (requestError: any) {
      const message =
        requestError?.response?.data?.message ??
        'Could not finalise payroll run.';

      setError(Array.isArray(message) ? message.join(' ') : message);
    } finally {
      setWorkingRunId('');
    }
  }

  async function cancelRun(runId: string) {
    const confirmed = window.confirm('Cancel this payroll run?');

    if (!confirmed) return;

    setWorkingRunId(runId);
    setError('');
    setSuccess('');

    try {
      const response = await api.patch<CreatePayrollRunResponse>(
        `/payroll/runs/${runId}/cancel`,
      );

      setRuns((current) =>
        current.map((run) =>
          run.id === runId ? response.data.payrollRun : run,
        ),
      );

      setSuccess(response.data.message);
    } catch (requestError: any) {
      const message =
        requestError?.response?.data?.message ?? 'Could not cancel payroll run.';

      setError(Array.isArray(message) ? message.join(' ') : message);
    } finally {
      setWorkingRunId('');
    }
  }

  async function deleteRun(runId: string) {
    const confirmed = window.confirm(
      'Delete this payroll run? This cannot be undone.',
    );

    if (!confirmed) return;

    setWorkingRunId(runId);
    setError('');
    setSuccess('');

    try {
      const response = await api.delete<{ message: string }>(
        `/payroll/runs/${runId}`,
      );

      setRuns((current) => current.filter((run) => run.id !== runId));
      setSuccess(response.data.message);
    } catch (requestError: any) {
      const message =
        requestError?.response?.data?.message ?? 'Could not delete payroll run.';

      setError(Array.isArray(message) ? message.join(' ') : message);
    } finally {
      setWorkingRunId('');
    }
  }

  return (
    <DashboardShell activePage="payroll">
      <div className="space-y-8">
        <section className="flex flex-col gap-5 border-b border-black/10 pb-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <Link
              href="/dashboard/payroll"
              className="mb-4 inline-flex items-center gap-2 text-sm font-medium text-gray-500 transition hover:text-black"
            >
              <ArrowLeft size={15} />
              Back to payroll
            </Link>

            <p className="mb-2 text-sm uppercase tracking-[0.25em] text-gray-400">
              Payroll batches
            </p>

            <h1 className="text-3xl font-semibold tracking-[-0.04em] text-[#111827]">
              Payroll runs
            </h1>

            <p className="mt-2 max-w-2xl text-sm leading-6 text-gray-500">
              Create monthly payroll batches, track totals, and finalise payroll
              periods once payslips are ready.
            </p>
          </div>

          <button
            type="button"
            onClick={loadPayrollRuns}
            className="inline-flex items-center justify-center gap-2 border border-black/10 bg-white px-5 py-3 text-sm font-medium text-gray-600 transition hover:border-black hover:text-black"
          >
            <RefreshCw size={16} />
            Refresh
          </button>
        </section>

        {error ? (
          <div className="border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        ) : null}

        {success ? (
          <div className="border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            {success}
          </div>
        ) : null}

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <StatCard
            title="Payroll runs"
            value={String(runs.length)}
            helper="Total batches created"
            icon={<WalletCards size={18} />}
          />

          <StatCard
            title="Draft"
            value={String(draftRuns.length)}
            helper="Open payroll periods"
            icon={<Clock3 size={18} />}
          />

          <StatCard
            title="Finalised"
            value={String(finalisedRuns.length)}
            helper="Closed payroll periods"
            icon={<CheckCircle2 size={18} />}
          />

          <StatCard
            title="Net paid"
            value={formatCurrency(totalNetPay)}
            helper={`Gross: ${formatCurrency(totalGrossPay)}`}
            icon={<ShieldCheck size={18} />}
            dark
          />
        </section>

        <section className="grid gap-6 xl:grid-cols-[380px_1fr]">
          <aside className="space-y-6">
            <form
              onSubmit={createPayrollRun}
              className="border border-black/10 bg-white"
            >
              <div className="border-b border-black/10 px-6 py-5">
                <div className="flex h-11 w-11 items-center justify-center border border-black/10 bg-[#111827] text-white">
                  <Plus size={18} />
                </div>

                <h2 className="mt-5 text-lg font-semibold tracking-[-0.03em] text-[#111827]">
                  Create payroll run
                </h2>

                <p className="mt-1 text-sm leading-6 text-gray-500">
                  Start a draft payroll batch for a selected month.
                </p>
              </div>

              <div className="space-y-4 p-6">
                <label className="block">
                  <span className="mb-2 block text-sm font-medium text-[#111827]">
                    Run title
                  </span>

                  <input
                    value={title}
                    onChange={(event) => setTitle(event.target.value)}
                    placeholder={`${monthLabel(periodMonth)} ${periodYear} Payroll Run`}
                    className="w-full border border-black/10 bg-[#f8fafc] px-4 py-3 text-sm outline-none transition focus:border-black"
                  />
                </label>

                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block">
                    <span className="mb-2 block text-sm font-medium text-[#111827]">
                      Month
                    </span>

                    <select
                      value={periodMonth}
                      onChange={(event) =>
                        setPeriodMonth(Number(event.target.value))
                      }
                      className="w-full border border-black/10 bg-[#f8fafc] px-4 py-3 text-sm outline-none transition focus:border-black"
                    >
                      {months.map((month) => (
                        <option key={month.value} value={month.value}>
                          {month.label}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="block">
                    <span className="mb-2 block text-sm font-medium text-[#111827]">
                      Year
                    </span>

                    <input
                      type="number"
                      value={periodYear}
                      onChange={(event) =>
                        setPeriodYear(Number(event.target.value))
                      }
                      className="w-full border border-black/10 bg-[#f8fafc] px-4 py-3 text-sm outline-none transition focus:border-black"
                    />
                  </label>
                </div>

                <label className="block">
                  <span className="mb-2 block text-sm font-medium text-[#111827]">
                    Notes
                  </span>

                  <textarea
                    value={notes}
                    onChange={(event) => setNotes(event.target.value)}
                    rows={4}
                    placeholder="Optional notes for this payroll run..."
                    className="w-full resize-none border border-black/10 bg-[#f8fafc] px-4 py-3 text-sm outline-none transition focus:border-black"
                  />
                </label>

                <button
                  type="submit"
                  disabled={creating}
                  className="inline-flex w-full items-center justify-center gap-2 border border-black bg-black px-5 py-3 text-sm font-medium text-white transition hover:bg-white hover:text-black disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {creating ? (
                    <Loader2 className="animate-spin" size={16} />
                  ) : (
                    <Plus size={16} />
                  )}
                  {creating ? 'Creating...' : 'Create payroll run'}
                </button>
              </div>
            </form>

            <section className="border border-black/10 bg-[#111827] p-6 text-white">
              <div className="flex h-11 w-11 items-center justify-center border border-white/15 bg-white/10">
                <FileText size={18} />
              </div>

              <h2 className="mt-5 text-lg font-semibold tracking-[-0.03em]">
                Payroll run workflow
              </h2>

              <p className="mt-2 text-sm leading-6 text-white/70">
                Create a draft run, add payroll items, generate payslips, then
                finalise the run once payroll is complete.
              </p>

              <Link
                href="/dashboard/payroll/run"
                className="mt-5 inline-flex w-full items-center justify-center gap-2 border border-white bg-white px-4 py-3 text-sm font-medium text-[#111827] transition hover:bg-transparent hover:text-white"
              >
                Run individual payroll
                <ArrowRight size={15} />
              </Link>
            </section>
          </aside>

          <section className="border border-black/10 bg-white">
            <div className="border-b border-black/10 px-6 py-5">
              <h2 className="text-lg font-semibold tracking-[-0.03em] text-[#111827]">
                Payroll run register
              </h2>

              <p className="mt-1 text-sm text-gray-500">
                Monthly payroll batches created in this workspace.
              </p>
            </div>

            <div className="p-6">
              {loading ? (
                <div className="flex min-h-[460px] items-center justify-center">
                  <div className="flex items-center gap-3 text-sm text-gray-500">
                    <Loader2 className="animate-spin" size={18} />
                    Loading payroll runs...
                  </div>
                </div>
              ) : runs.length === 0 ? (
                <div className="border border-dashed border-black/15 bg-[#f8fafc] px-5 py-14 text-center">
                  <CalendarDays size={34} className="mx-auto text-gray-300" />

                  <p className="mt-4 text-sm font-medium text-[#111827]">
                    No payroll runs yet
                  </p>

                  <p className="mt-1 text-sm text-gray-500">
                    Create your first monthly payroll batch.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {runs.map((run) => (
                    <article
                      key={run.id}
                      className="border border-black/10 bg-[#f8fafc] p-5"
                    >
                      <div className="grid gap-5 2xl:grid-cols-[1fr_auto]">
                        <div>
                          <div className="flex flex-wrap items-center gap-3">
                            <div className="flex h-11 w-11 items-center justify-center border border-black/10 bg-white text-gray-500">
                              <WalletCards size={18} />
                            </div>

                            <div>
                              <h3 className="text-sm font-semibold text-[#111827]">
                                {run.title}
                              </h3>

                              <p className="mt-1 text-xs text-gray-500">
                                {monthLabel(run.periodMonth)} {run.periodYear} ·
                                Created {formatDate(run.createdAt)}
                              </p>
                            </div>

                            <span
                              className={`inline-flex items-center gap-1.5 border px-2 py-1 text-[11px] font-medium ${statusClass(
                                run.status,
                              )}`}
                            >
                              {statusIcon(run.status)}
                              {statusLabel(run.status)}
                            </span>
                          </div>

                          <div className="mt-5 grid gap-3 md:grid-cols-4">
                            <MiniMetric
                              label="Employees"
                              value={String(run.employeeCount || run.itemCount)}
                            />

                            <MiniMetric
                              label="Gross"
                              value={formatCurrency(run.totalGrossPay)}
                            />

                            <MiniMetric
                              label="Deductions"
                              value={formatCurrency(run.totalDeductions)}
                            />

                            <MiniMetric
                              label="Net pay"
                              value={formatCurrency(run.totalNetPay)}
                            />
                          </div>

                          {run.notes ? (
                            <p className="mt-4 text-sm leading-6 text-gray-500">
                              {run.notes}
                            </p>
                          ) : null}
                        </div>

                        <div className="flex flex-wrap gap-2 2xl:justify-end">
                          <Link
                            href={`/dashboard/payroll/runs/${run.id}`}
                            className="inline-flex items-center justify-center gap-2 border border-black bg-black px-4 py-2 text-sm font-medium text-white transition hover:bg-white hover:text-black"
                          >
                            Open
                            <ArrowRight size={15} />
                          </Link>

                          {run.status === 'DRAFT' ? (
                            <>
                              <button
                                type="button"
                                onClick={() => finaliseRun(run.id)}
                                disabled={workingRunId === run.id}
                                className="inline-flex items-center justify-center gap-2 border border-emerald-700 bg-white px-4 py-2 text-sm font-medium text-emerald-700 transition hover:bg-emerald-700 hover:text-white disabled:cursor-not-allowed disabled:opacity-60"
                              >
                                {workingRunId === run.id ? (
                                  <Loader2
                                    className="animate-spin"
                                    size={15}
                                  />
                                ) : (
                                  <CheckCircle2 size={15} />
                                )}
                                Finalise
                              </button>

                              <button
                                type="button"
                                onClick={() => cancelRun(run.id)}
                                disabled={workingRunId === run.id}
                                className="inline-flex items-center justify-center gap-2 border border-red-700 bg-white px-4 py-2 text-sm font-medium text-red-700 transition hover:bg-red-700 hover:text-white disabled:cursor-not-allowed disabled:opacity-60"
                              >
                                <XCircle size={15} />
                                Cancel
                              </button>

                              <button
                                type="button"
                                onClick={() => deleteRun(run.id)}
                                disabled={workingRunId === run.id}
                                className="inline-flex items-center justify-center gap-2 border border-black/10 bg-white px-4 py-2 text-sm font-medium text-gray-600 transition hover:border-red-700 hover:text-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                              >
                                <Trash2 size={15} />
                                Delete
                              </button>
                            </>
                          ) : null}
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>
          </section>
        </section>
      </div>
    </DashboardShell>
  );
}

function StatCard({
  title,
  value,
  helper,
  icon,
  dark,
}: {
  title: string;
  value: string;
  helper: string;
  icon: React.ReactNode;
  dark?: boolean;
}) {
  return (
    <div
      className={`border p-5 ${
        dark
          ? 'border-[#111827] bg-[#111827] text-white'
          : 'border-black/10 bg-white text-[#111827]'
      }`}
    >
      <div className="flex items-center justify-between gap-4">
        <p
          className={`text-xs uppercase tracking-[0.18em] ${
            dark ? 'text-white/50' : 'text-gray-400'
          }`}
        >
          {title}
        </p>

        <div className={dark ? 'text-white/60' : 'text-gray-400'}>{icon}</div>
      </div>

      <p className="mt-3 text-2xl font-semibold tracking-[-0.05em]">{value}</p>

      <p className={`mt-1 text-sm ${dark ? 'text-white/60' : 'text-gray-500'}`}>
        {helper}
      </p>
    </div>
  );
}

function MiniMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="border border-black/10 bg-white p-3">
      <p className="text-xs uppercase tracking-[0.16em] text-gray-400">
        {label}
      </p>

      <p className="mt-2 text-sm font-semibold text-[#111827]">{value}</p>
    </div>
  );
}