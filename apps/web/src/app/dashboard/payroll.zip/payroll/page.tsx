'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  ArrowRight,
  Calculator,
  Eye,
  EyeOff,
  FileText,
  Loader2,
  ReceiptText,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  WalletCards,
} from 'lucide-react';
import { DashboardShell } from '@/components/dashboard/DashboardShell';
import { api } from '@/lib/api';

type EmployeeDocument = {
  id: string;
  employeeId: string;
  category: string;
  title: string;
  originalName: string;
  mimeType: string;
  sizeBytes?: number;
  visibleToEmployee: boolean;
  isConfidential: boolean;
  createdAt: string;
  employee?: {
    id: string;
    employeeNumber: string;
    firstName: string;
    lastName: string;
    email?: string | null;
    jobTitle?: string | null;
    department?: {
      id: string;
      name: string;
    } | null;
  } | null;
};

function formatDate(value?: string | null) {
  if (!value) {
    return 'Not set';
  }

  return new Intl.DateTimeFormat('en-ZA', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  }).format(new Date(value));
}

function formatFileSize(sizeBytes?: number | null) {
  if (!sizeBytes) {
    return 'Size unavailable';
  }

  if (sizeBytes < 1024) {
    return `${sizeBytes} B`;
  }

  if (sizeBytes < 1024 * 1024) {
    return `${(sizeBytes / 1024).toFixed(1)} KB`;
  }

  return `${(sizeBytes / (1024 * 1024)).toFixed(1)} MB`;
}

function employeeName(document: EmployeeDocument) {
  if (!document.employee) {
    return 'Unassigned employee';
  }

  return `${document.employee.firstName} ${document.employee.lastName}`;
}

function getMonthKey(value: string) {
  const date = new Date(value);

  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}

export default function PayrollPage() {
  const [documents, setDocuments] = useState<EmployeeDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadPayrollData();
  }, []);

  const payslips = useMemo(() => {
    return documents.filter((document) => document.category === 'PAYSLIP');
  }, [documents]);

  const recentPayslips = useMemo(() => {
    return [...payslips]
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      )
      .slice(0, 6);
  }, [payslips]);

  const visiblePayslips = useMemo(() => {
    return payslips.filter((document) => document.visibleToEmployee);
  }, [payslips]);

  const hiddenPayslips = useMemo(() => {
    return payslips.filter((document) => !document.visibleToEmployee);
  }, [payslips]);

  const confidentialPayslips = useMemo(() => {
    return payslips.filter((document) => document.isConfidential);
  }, [payslips]);

  const generatedPayslips = useMemo(() => {
    return payslips.filter((document) => document.mimeType === 'text/html');
  }, [payslips]);

  const uniqueEmployeesWithPayslips = useMemo(() => {
    return new Set(payslips.map((document) => document.employeeId)).size;
  }, [payslips]);

  const thisMonthPayslips = useMemo(() => {
    const now = new Date();
    const currentMonthKey = `${now.getFullYear()}-${String(
      now.getMonth() + 1,
    ).padStart(2, '0')}`;

    return payslips.filter(
      (document) => getMonthKey(document.createdAt) === currentMonthKey,
    );
  }, [payslips]);

  async function loadPayrollData() {
    setLoading(true);
    setError('');

    try {
      const response = await api.get<EmployeeDocument[]>('/employees/documents');
      setDocuments(response.data);
    } catch (requestError: any) {
      const message =
        requestError?.response?.data?.message ?? 'Could not load payroll data.';

      setError(Array.isArray(message) ? message.join(' ') : message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <DashboardShell activePage="payroll">
      <div className="space-y-8">
        <section className="flex flex-col gap-5 border-b border-black/10 pb-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="mb-2 text-sm uppercase tracking-[0.25em] text-gray-400">
              Payroll centre
            </p>

            <h1 className="text-3xl font-semibold tracking-[-0.04em] text-[#111827]">
              Payroll
            </h1>

            <p className="mt-2 max-w-2xl text-sm leading-6 text-gray-500">
              Run payroll calculations, generate payslips, apply automatic PAYE,
              and store payroll records against employee profiles.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={loadPayrollData}
              className="inline-flex items-center justify-center gap-2 border border-black/10 bg-white px-5 py-3 text-sm font-medium text-gray-600 transition hover:border-black hover:text-black"
            >
              <RefreshCw size={16} />
              Refresh
            </button>

            <Link
              href="/dashboard/payroll/run"
              className="inline-flex items-center justify-center gap-2 border border-black bg-black px-5 py-3 text-sm font-medium text-white transition hover:bg-white hover:text-black"
            >
              <Calculator size={16} />
              Run payroll
            </Link>
          </div>
        </section>

        {error ? (
          <div className="border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        ) : null}

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <StatCard
            title="Payslips"
            value={String(payslips.length)}
            helper="Total payroll documents"
            icon={<ReceiptText size={18} />}
          />

          <StatCard
            title="This month"
            value={String(thisMonthPayslips.length)}
            helper="Generated this month"
            icon={<TrendingUp size={18} />}
          />

          <StatCard
            title="Employees"
            value={String(uniqueEmployeesWithPayslips)}
            helper="With saved payslips"
            icon={<WalletCards size={18} />}
          />

          <StatCard
            title="PAYE"
            value="Auto"
            helper="SARS annualised mode ready"
            icon={<Sparkles size={18} />}
            dark
          />
        </section>

        <section className="grid gap-6 xl:grid-cols-[380px_1fr]">
          <aside className="space-y-6">
            <section className="border border-black/10 bg-[#111827] p-6 text-white">
              <div className="flex h-11 w-11 items-center justify-center border border-white/15 bg-white/10">
                <WalletCards size={19} />
              </div>

              <h2 className="mt-5 text-lg font-semibold tracking-[-0.03em]">
                Payroll workflow
              </h2>

              <p className="mt-2 text-sm leading-6 text-white/70">
                Calculate earnings, deductions, UIF, PAYE and net pay. Then
                generate a formal payslip and save it to employee documents.
              </p>

              <div className="mt-6 grid gap-3">
                <Link
                  href="/dashboard/payroll/run"
                  className="inline-flex items-center justify-center gap-2 border border-white bg-white px-4 py-3 text-sm font-medium text-[#111827] transition hover:bg-transparent hover:text-white"
                >
                  <Calculator size={16} />
                  Run payroll
                </Link>

                <Link
                  href="/dashboard/payslips"
                  className="inline-flex items-center justify-center gap-2 border border-white/20 bg-white/10 px-4 py-3 text-sm font-medium text-white transition hover:border-white"
                >
                  <ReceiptText size={16} />
                  Payslip register
                </Link>

                <Link
                  href="/dashboard/documents"
                  className="inline-flex items-center justify-center gap-2 border border-white/20 bg-white/10 px-4 py-3 text-sm font-medium text-white transition hover:border-white"
                >
                  <FileText size={16} />
                  Document centre
                </Link>
              </div>
            </section>

            <section className="border border-black/10 bg-white p-6">
              <div className="flex h-11 w-11 items-center justify-center border border-black/10 bg-[#f8fafc] text-gray-500">
                <Sparkles size={19} />
              </div>

              <h2 className="mt-5 text-lg font-semibold tracking-[-0.03em] text-[#111827]">
                Automatic PAYE
              </h2>

              <p className="mt-2 text-sm leading-6 text-gray-500">
                Automatic SARS annualised PAYE is available during payroll runs.
                Manual PAYE remains available for corrections and edge cases.
              </p>
            </section>

            <section className="border border-black/10 bg-white p-6">
              <div className="flex h-11 w-11 items-center justify-center border border-black/10 bg-[#f8fafc] text-gray-500">
                <ShieldCheck size={19} />
              </div>

              <h2 className="mt-5 text-lg font-semibold tracking-[-0.03em] text-[#111827]">
                Payroll controls
              </h2>

              <div className="mt-4 space-y-3">
                <MiniStat
                  label="Visible to employees"
                  value={String(visiblePayslips.length)}
                  icon={<Eye size={15} />}
                />

                <MiniStat
                  label="Hidden payslips"
                  value={String(hiddenPayslips.length)}
                  icon={<EyeOff size={15} />}
                />

                <MiniStat
                  label="Confidential"
                  value={String(confidentialPayslips.length)}
                  icon={<ShieldCheck size={15} />}
                />

                <MiniStat
                  label="Generated HTML"
                  value={String(generatedPayslips.length)}
                  icon={<Sparkles size={15} />}
                />
              </div>
            </section>
          </aside>

          <section className="border border-black/10 bg-white">
            <div className="flex flex-col gap-4 border-b border-black/10 px-6 py-5 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-lg font-semibold tracking-[-0.03em] text-[#111827]">
                  Recent payslips
                </h2>

                <p className="mt-1 text-sm text-gray-500">
                  Latest generated and saved payroll records.
                </p>
              </div>

              <Link
                href="/dashboard/payroll/run"
                className="inline-flex items-center justify-center gap-2 border border-black bg-black px-4 py-2 text-sm font-medium text-white transition hover:bg-white hover:text-black"
              >
                Run payroll
                <ArrowRight size={15} />
              </Link>
            </div>

            <div className="p-6">
              {loading ? (
                <div className="flex min-h-[420px] items-center justify-center">
                  <div className="flex items-center gap-3 text-sm text-gray-500">
                    <Loader2 className="animate-spin" size={18} />
                    Loading payroll records...
                  </div>
                </div>
              ) : recentPayslips.length === 0 ? (
                <div className="border border-dashed border-black/15 bg-[#f8fafc] px-5 py-14 text-center">
                  <ReceiptText size={32} className="mx-auto text-gray-300" />

                  <p className="mt-4 text-sm font-medium text-[#111827]">
                    No payslips generated yet
                  </p>

                  <p className="mt-1 text-sm text-gray-500">
                    Run payroll and save the first payslip to employee
                    documents.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentPayslips.map((document) => (
                    <article
                      key={document.id}
                      className="border border-black/10 bg-[#f8fafc] p-5"
                    >
                      <div className="grid gap-4 xl:grid-cols-[1fr_auto]">
                        <div>
                          <div className="flex flex-wrap items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center border border-black/10 bg-white text-gray-500">
                              <ReceiptText size={17} />
                            </div>

                            <div>
                              <h3 className="text-sm font-semibold text-[#111827]">
                                {document.title}
                              </h3>

                              <p className="mt-1 text-xs text-gray-500">
                                {employeeName(document)} ·{' '}
                                {formatDate(document.createdAt)}
                              </p>
                            </div>

                            {document.visibleToEmployee ? (
                              <span className="border border-emerald-200 bg-emerald-50 px-2 py-1 text-[11px] font-medium text-emerald-700">
                                Visible
                              </span>
                            ) : (
                              <span className="border border-gray-200 bg-gray-50 px-2 py-1 text-[11px] font-medium text-gray-500">
                                Hidden
                              </span>
                            )}

                            {document.isConfidential ? (
                              <span className="border border-red-200 bg-red-50 px-2 py-1 text-[11px] font-medium text-red-700">
                                Confidential
                              </span>
                            ) : null}
                          </div>

                          <div className="mt-4 grid gap-3 text-sm text-gray-500 md:grid-cols-2">
                            <InfoBlock
                              label="File"
                              value={document.originalName}
                            />

                            <InfoBlock
                              label="Size"
                              value={formatFileSize(document.sizeBytes)}
                            />
                          </div>
                        </div>

                        {document.employee ? (
                          <Link
                            href={`/dashboard/employees/${document.employee.id}/documents`}
                            className="inline-flex items-center justify-center gap-2 border border-black/10 bg-white px-4 py-2 text-sm font-medium text-gray-600 transition hover:border-black hover:text-black"
                          >
                            Open documents
                            <ArrowRight size={15} />
                          </Link>
                        ) : null}
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>
          </section>
        </section>
      </div>
    </DashboardShell>
  );
}

function StatCard({
  title,
  value,
  helper,
  icon,
  dark,
}: {
  title: string;
  value: string;
  helper: string;
  icon: React.ReactNode;
  dark?: boolean;
}) {
  return (
    <div
      className={`border p-5 ${
        dark
          ? 'border-[#111827] bg-[#111827] text-white'
          : 'border-black/10 bg-white text-[#111827]'
      }`}
    >
      <div className="flex items-center justify-between gap-4">
        <p
          className={`text-xs uppercase tracking-[0.18em] ${
            dark ? 'text-white/50' : 'text-gray-400'
          }`}
        >
          {title}
        </p>

        <div className={dark ? 'text-white/60' : 'text-gray-400'}>{icon}</div>
      </div>

      <p className="mt-3 text-2xl font-semibold tracking-[-0.05em]">{value}</p>

      <p className={`mt-1 text-sm ${dark ? 'text-white/60' : 'text-gray-500'}`}>
        {helper}
      </p>
    </div>
  );
}

function MiniStat({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border border-black/10 bg-[#f8fafc] p-3">
      <div className="flex items-center gap-2 text-sm text-gray-500">
        {icon}
        <span>{label}</span>
      </div>

      <span className="text-sm font-semibold text-[#111827]">{value}</span>
    </div>
  );
}

function InfoBlock({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0 border border-black/10 bg-white p-4">
      <p className="text-xs uppercase tracking-[0.16em] text-gray-400">
        {label}
      </p>

      <p className="mt-2 break-words text-sm font-medium leading-6 text-[#111827]">
        {value}
      </p>
    </div>
  );
}